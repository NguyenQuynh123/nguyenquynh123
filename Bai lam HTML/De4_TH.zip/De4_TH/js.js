﻿function select_TheHouseBunny() {
    document.getElementById('movietrailers_TheHouseBunny').style.display = 'block';
    document.getElementById('movietrailers_EagleEye').style.display = 'none';
    document.getElementById('movietrailers_JourneyToTheCentre').style.display = 'none';
}
function select_EagleEye() {
    document.getElementById('movietrailers_TheHouseBunny').style.display = 'none';
    document.getElementById('movietrailers_EagleEye').style.display = 'block';
    document.getElementById('movietrailers_JourneyToTheCentre').style.display = 'none';
}
function select_Journey() {
    document.getElementById('movietrailers_TheHouseBunny').style.display = 'none';
    document.getElementById('movietrailers_EagleEye').style.display = 'none';
    document.getElementById('movietrailers_JourneyToTheCentre').style.display = 'block';
}
function tangLen5Sao_reportEE() {
    document.getElementById('report_3sao').style.display = 'none';
    document.getElementById('report_5sao').style.display = 'block';
}
function giamXuong3Sao_reportEE() {
    document.getElementById('report_3sao').style.display = 'block';
    document.getElementById('report_5sao').style.display = 'none';
}
function tangLen4Sao_reportHB() {
    document.getElementById('report_2sao').style.display = 'none';
    document.getElementById('report_4sao').style.display = 'block';
}
function giamXuong2Sao_reportHB() {
    document.getElementById('report_2sao').style.display = 'block';
    document.getElementById('report_4sao').style.display = 'none';
}